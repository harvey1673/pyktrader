# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.shortcuts import render
from django.http import JsonResponse
import sys
from config import MARKET_DB, PYCMQLIB_LOC
import pandas as pd
import json
from forms import SpotForm, FutForm

sys.path.append(PYCMQLIB_LOC)
import dbaccess
import curve_strip_mark

def spot_price(request):
    valid = False
    if request.method == 'POST':
        form = SpotForm(request.POST)
        if form.is_valid():
            valid = True
            conn = dbaccess.connect(**MARKET_DB)
            spotID = form.cleaned_data['spotID']
            date_start = form.cleaned_data['date_start']
            date_end = form.cleaned_data['date_end']
            data = dbaccess.load_daily_data_to_df(conn, 'spot_daily', spotID, date_start, date_end, field = 'spotID', date_as_str = True)
            date= list(data['date'])
            price = list(data['close'])
            conn.close()          
            return render(request, 'data_query/spot_price.html',{'data':data,
                                                            'form':form,
                                                            'valid':valid,
                                                            'date':date,
                                                            'price':price
                                                            })
#            return HttpResponse(date_start)
    else:
        form = SpotForm()
        return render(request, 'data_query/spot_price.html', {'form':form,
                                                         'valid':valid,
                                                         })
    
def fut_curve(request):
    valid = False
    if request.method == 'POST':
        form = FutForm(request.POST)
        if form.is_valid():
            valid = True
            conn = dbaccess.connect(**MARKET_DB)
            instID = form.cleaned_data['instID']
            date = form.cleaned_data['date']
            sql = "SELECT instID, exch, date, close FROM fut_daily WHERE instID like '{}____' and date like '{}%'".format(instID, date)
            data = pd.read_sql_query(sql, conn)
            instID = list(data['instID'])
            price = list(data['close'])
            conn.close()
            return render(request, 'data_query/fut_curve.html',{'data':data,
                                                            'form':form,
                                                            'valid':valid,
                                                            'instID':instID,
                                                            'price':price
                                                            })
    else:
        form = FutForm()
        return render(request, 'data_query/fut_curve.html', {'form':form,
                                                         'valid':valid,
                                                         })

def mark_curve(request):
    MONTH_TENORS = ['1710', '1711', '1712', '1801', '1802', '1803', '1804', '1805', 
                '1806', '1807', '1808', '1809', '1810', '1811', '1812']

    SPREAD_TENORS = ['1801', '1710/1711', '1711/1712', '1712/1801', '1801/1802',
             '1802/1803', '1803/1804', '18Q1/18Q2', '18Q2/18Q3', '18Q3/18Q4',
             '1804/1805/1806', '1806/1807/1808', '1807/1808/1809', 
             '1809/1810/1811', '1810/1811/1812']
    
    SPREADS = (65.0, 0.55, 0.4, 0.4, 0.4, 0.4, 0.4, 1.2,
                   1.05, 0.9, 0.05, 0.05, 0.0, 0.0, 0.0)
    
    spread_pairs = json.dumps(SPREAD_TENORS)
    months = json.dumps(MONTH_TENORS)
    spreads = list(SPREADS)
    return render(request, 'data_query/mark_curve.html', {'spread_pairs': spread_pairs,
                                                         'spreads': spreads,
                                                         'months': months})
        
def upload_fut_realtime_database(request):
    success = False
    months = request.GET.getlist("months[]")
    months = map(lambda x: 'fef'+str(x), months)
    px = request.GET.getlist("px[]")
    px = map(float, px)
    timestamp = request.GET.getlist("timestamp[]")
    timestamp = map(str, timestamp)
    conn = dbaccess.connect(**MARKET_DB)
    conn.commit()
    conn.close()
    return JsonResponse({'value':success,
                         'px':px,
                         'months': months,
                         'timestamp':timestamp})

def test_mark_curve(request):
    output = {}
    spread_pairs = request.GET.getlist("spread_pairs[]")
    spreads = request.GET.getlist("spreads[]")
    spreads = map(float, spreads)
    months = request.GET.getlist("months[]")
    output['px'] = curve_strip_mark.get_curve(months, spread_pairs, spreads)['close'].round(2).to_json()

    return JsonResponse(output)

def test_compute_table(request):
    output = {}
    spreads = request.GET.getlist("spreads[]")
    px = request.GET.getlist("px[]")
    months = request.GET.getlist("months[]")
    px = map(float, px)
    
    spread_pairs = []
    for s in spreads:
        for sp in spreads:
            spread_pairs.append(s+'/'+sp)
    for i in range(len(spreads)):
        output[str(i+1)] = []
        df = pd.DataFrame({'instID':months,
                       'close':px})
        for j in range(len(spreads)):
            output[str(i+1)].append(round(curve_strip_mark.cal_spread(df, spread_pairs[i*len(spreads)+j]), 2))
    
    output['record'] = []
    for sprd in spreads:
        output['record'].append(round(curve_strip_mark.calc_strip(df, sprd),2))
    return JsonResponse(output)						 