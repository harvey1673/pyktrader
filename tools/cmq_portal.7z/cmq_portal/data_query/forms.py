from django import forms

class SpotForm(forms.Form):
    spotID = forms.CharField(label='Input spotID', max_length=128)
    date_start = forms.DateField(label = 'Select start date', widget=forms.SelectDateWidget)
    date_end = forms.DateField(label = 'Select end date', widget = forms.SelectDateWidget)
    
class FutForm(forms.Form):
    instID = forms.CharField(label='Future tick symbol', max_length=10)
    date = forms.DateField(label = 'Select date', widget=forms.SelectDateWidget)
    