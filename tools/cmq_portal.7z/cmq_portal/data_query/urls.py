from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^spot/$', views.spot_price, name='spot'),        
    url(r'^fut/$', views.fut_curve, name='fut'),
    url(r'^mark_curve/$', views.mark_curve, name='mark_curve'),
	url(r'^test-mark-curve/$', views.test_mark_curve, name='test_mark_curve'),
	url(r'^test-compute-table/$', views.test_compute_table, name='test_compute_table'),
	url(r'^upload-fut-realtime-database/$', views.upload_fut_realtime_database, name='upload_fut_realtime_database'),
    ]