# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import JsonResponse
import sys
import numpy as np
import pandas as pd
from datetime import datetime
from config import PYCMQLIB_LOC, TRADE_DB
sys.path.append(PYCMQLIB_LOC)
import dbaccess
import cmq_book
import cmq_inst
import risk_scen_report
# For risk engine viewer

# This part for querying trading books
def trade_book(request):
    if request.method == 'POST':
        tradeID = request.POST.getlist('tradeID')
        strat = request.POST.getlist('strategy')
        date = request.POST.getlist('enterDate')
        conn = dbaccess.connect(**TRADE_DB)
        sql = "select strategy, internal_id, enter_date, cpty, day1_comments, status, trader, sales, desk, commission, positions \
                from deals \
                where strategy = '{}'".format(strat[0])
        data = pd.read_sql_query(sql, conn)
        conn.close()
        return render(request, 'risk_engine/trading_book.html', {'data': data})
    else:
        return render(request, 'risk_engine/trading_book.html', {})

def risk_viewer(request):
    return render(request, 'risk_engine/risk_viewer.html', {})

# Risk viewer backend logical calculations
def risk_processor(request):
    output = {}

    bookName = request.GET.getlist("bookName[]")
    date = request.GET.getlist("date[]")
    crit = request.GET.getlist("crit[]")
    dt = datetime.strptime(str(date[0]), "%Y-%m-%d")
    dt = dt.date()
    bookName = str(bookName[0]).upper()
    bookName = cmq_book.get_book_from_db(bookName, [2, ])

    if str(crit[0]).upper() == 'RISK':
        vol, delta, gamma, vega, theta, df = risk_scen_report.run_book_report(dt, bookName)
        output['vol'] = vol.fillna(0).to_html()
        output['delta'] = delta.fillna(0).to_html()
        output['gamma'] = gamma.fillna(0).to_html()
        output['vega'] = vega.fillna(0).to_html()
        output['theta'] = theta.fillna(0).to_html()
        output['df'] = df.fillna(0).to_html()
        return JsonResponse(output)
    else:
        settings = request.GET.getlist("settings[]")
        scens_vol = ['COMVolATM', 'SGXIRO', [-0.03, -0.02, -0.01, 0.0, 0.01, 0.02, 0.03], 0]
        output['vol_ladder'] = risk_scen_report.book_greek_scen_report(dt, bookName, scens=scens_vol).fillna(
            0).to_html()
        if settings[0] == 'true':
            if settings[1] == 'true':
                shiftType = 0
            else:
                shiftType = 1
            minimum = float(settings[2])
            maximum = float(settings[3])
            step = float(settings[4])
            scenario = np.arange(minimum, maximum, step).tolist()
            scenario.append(maximum)
            output['ladder'] = risk_scen_report.book_greek_scen_report(dt, bookName,
                                                                       scens=['COMFwd', 'SGXIRO', scenario,
                                                                              shiftType]).fillna(0).to_html()
        else:
            scens_vol = ['COMVolATM', 'SGXIRO', [- 5.0, -3.0, -1.0, 0.0, 1.0, 3.0, 5.0], cmq_inst.CurveShiftType.Abs]
            df = risk_scen_report.book_greek_scen_report(dt, bookName)
            output['ladder'] = df.fillna(0).to_html()
        return JsonResponse(output)


def sync(request):
    import subprocess
    subprocess.Popen('start cmd /c' + PYCMQLIB_LOC + 'sync.bat', shell=True)
    return JsonResponse({})

def twod_scenario(request):
    return render(request, 'risk_engine/2d_scenario.html', {})

def twod_scenario_cal(request):
    greeks = ['cmdelta', 'cmvega_atm', 'cmgamma']
    bookName = request.GET.getlist("bookName[]")
    date = request.GET.getlist("date[]")
    dt = datetime.strptime(str(date[0]), "%Y-%m-%d")
    dt = dt.date()
    bookName = str(bookName[0]).upper()
    bookName = cmq_book.get_book_from_db(bookName, [2, ])

    greeks = ['cmdelta', 'cmvega_atm', 'cmgamma']

    output = risk_scen_report.scenario_2d_report(dt, bookName, greeks)
    output = {'delta': output['cmdelta'].round(2).to_html(),
              'vega': output['cmvega_atm'].round(2).to_html(),
              'gamma': output['cmgamma'].round(2).to_html()
              }
    return JsonResponse(output)

def book_trade(request):  # this function handles book trade website
    return render(request, 'risk_engine/book_trade.html', {})
