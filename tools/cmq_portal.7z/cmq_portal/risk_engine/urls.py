from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^trading-book/$', views.trade_book, name='trading_book'),
	url(r'^risk-viewer/$', views.risk_viewer, name='risk_viewer'),
    url(r'^risk-processor/$', views.risk_processor, name='risk_processor'),
    url(r'^sync/$', views.sync, name='sync'),
    url(r'^2D-scenario/$', views.twod_scenario, name="2d_scenario"),
    url(r'^2D-scenario-cal/$', views.twod_scenario_cal, name='2d_scenario_cal'),
    url(r'^book-trade/$', views.book_trade, name='book_trade'),
    ]