PYCMQLIB_LOC = 'C:/dev/pycmqlib/'
MARKET_DB = {'database': "C:\\dev\\pycmqlib\\market_data.db"}
TRADE_DB = {'database': 'C:\\dev\\pycmqlib\\deal_data.db'}