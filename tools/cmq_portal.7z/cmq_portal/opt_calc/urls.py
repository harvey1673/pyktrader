from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^BS-pricer/$', views.BS_pricer, name='BS_pricer'),
	url(r'^bs_py/$', views.bs_py, name='bs_py'),
    url(r'^asian-forward-option/$', views.AsianFwd_page, name='asian_fwd_page'),
    url(r'^asian-forward/$', views.AsianFwd, name='AsianFwd'),
	url(r'^spread-option/$', views.spread_option, name='spread_option'),
	url(r'^cal-spread/$', views.kirk_approx, name='two_asset_spdopt'),
    ]