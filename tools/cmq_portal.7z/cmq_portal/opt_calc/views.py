# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.shortcuts import render
from django.http import JsonResponse
import sys
from datetime import datetime
from config import PYCMQLIB_LOC
sys.path.append(PYCMQLIB_LOC)
import bsopt

# option pricer
def BS_pricer(request):
    valid = False
    if request.method == 'POST':
        valid = True
        IsCall = request.POST.getlist('IsCall')
        S = request.POST.getlist('S')
        K = request.POST.getlist('K')
        Vol = request.POST.getlist('Vol')
        Texp = request.POST.getlist('Texp')
        Rf = request.POST.getlist('Rf')
        Rd = request.POST.getlist('Rd')
        res = []
        for i in range(len(IsCall)):
            res.append(bsopt.BSOpt(IsCall[i], float(S[i]), float(K[i]), float(Vol[i]), float(Texp[i]), float(Rf[i]), float(Rd[i])))
        return render(request, 'opt_calc/BS_pricer.html', {'res':res, 'valid':valid})
    else:
        return render(request, 'opt_calc/BS_pricer.html', {'valid':valid})
    
def bs_py(request):
    IsCall = request.GET.getlist('IsCall[]')
    F = request.GET.getlist('S[]')
    K = request.GET.getlist('K[]')
    Vol = request.GET.getlist('Vol[]')
    t = request.GET.getlist('t[]')
    T = request.GET.getlist('T[]')
    ir = request.GET.getlist('ir[]')
    output = {}
    
    value = {}
    for i in range(len(IsCall)):
        d1 = datetime.strptime(str(t[i]), "%Y-%m-%d")
        d2 = datetime.strptime(str(T[i]), "%Y-%m-%d")
        delta = float((d2 - d1).days)
        Texp = float(delta/365)
        value[i] = bsopt.BSFwd(str(IsCall[i]), float(F[i]), float(K[i]), float(Vol[i]), Texp, float(ir[i]))
    output['premium'] = value
    
    value = {}
    for i in range(len(IsCall)):
        d1 = datetime.strptime(str(t[i]), "%Y-%m-%d")
        d2 = datetime.strptime(str(T[i]), "%Y-%m-%d")
        delta = float((d2 - d1).days)
        Texp = float(delta/365)
        value[i] = bsopt.BSFwdDelta(str(IsCall[i]), float(F[i]), float(K[i]), float(Vol[i]), Texp, float(ir[i]))
    output['delta'] = value
    
    value = {}
    for i in range(len(IsCall)):
        d1 = datetime.strptime(str(t[i]), "%Y-%m-%d")
        d2 = datetime.strptime(str(T[i]), "%Y-%m-%d")
        delta = float((d2 - d1).days)
        Texp = float(delta/365)
        value[i] = bsopt.BSVega(float(F[i]), float(K[i]), float(Vol[i]), Texp, float(ir[i]), float(ir[i]))
    output['vega'] = value
    return JsonResponse(output)

# Asian Forward Option page
def AsianFwd_page(request):
    return render(request, 'opt_calc/AsianFwd_page.html', {})

def AsianFwd(request):
    IsCall = request.GET.getlist('IsCall[]')
    Fwd = request.GET.getlist('Fwd[]')
    Avg = request.GET.getlist('Avg[]')
    Vol = request.GET.getlist('Vol[]')
    K = request.GET.getlist('K[]')
    Period = request.GET.getlist('Period[]')
    t = request.GET.getlist('t[]')
    T = request.GET.getlist('T[]')
    Rf = request.GET.getlist('Rf[]')
    
    output = {}
    
    value = {}
    for i in range(len(IsCall)):
        d1 = datetime.strptime(str(t[i]), "%Y-%m-%d")
        d2 = datetime.strptime(str(T[i]), "%Y-%m-%d")
        delta = float((d2 - d1).days)
        Texp = float(delta/365)
        value[i] = bsopt.AsianOptTW_Fwd(str(IsCall[i]), float(Fwd[i]), float(K[i]), float(Avg[i]), float(Vol[i]), Texp, float(Period[i]), float(Rf[i]))
    output['premium'] = value
    
    value = {}
    for i in range(len(IsCall)):
        d1 = datetime.strptime(str(t[i]), "%Y-%m-%d")
        d2 = datetime.strptime(str(T[i]), "%Y-%m-%d")
        delta = float((d2 - d1).days)
        Texp = float(delta/365)
        value[i] = bsopt.AsianFwdDelta(str(IsCall[i]), float(Fwd[i]), float(K[i]), float(Avg[i]), float(Vol[i]), Texp, float(Period[i]), float(Rf[i]))
    output['delta'] = value
    
    value = {}
    for i in range(len(IsCall)):
        d1 = datetime.strptime(str(t[i]), "%Y-%m-%d")
        d2 = datetime.strptime(str(T[i]), "%Y-%m-%d")
        delta = float((d2 - d1).days)
        Texp = float(delta/365)
        value[i] = bsopt.AsianFwdGamma(float(Fwd[i]), float(K[i]), float(Avg[i]), float(Vol[i]), Texp, float(Period[i]), float(Rf[i]))
    output['gamma'] = value
    
    value = {}
    for i in range(len(IsCall)):
        d1 = datetime.strptime(str(t[i]), "%Y-%m-%d")
        d2 = datetime.strptime(str(T[i]), "%Y-%m-%d")
        delta = float((d2 - d1).days)
        Texp = float(delta/365)
        value[i] = bsopt.AsianFwdTheta(str(IsCall[i]), float(Fwd[i]), float(K[i]), float(Avg[i]), float(Vol[i]), Texp, float(Period[i]), float(Rf[i]))
    output['theta'] = value

    value = {}
    for i in range(len(IsCall)):
        d1 = datetime.strptime(str(t[i]), "%Y-%m-%d")
        d2 = datetime.strptime(str(T[i]), "%Y-%m-%d")
        delta = float((d2 - d1).days)
        Texp = float(delta/365)
        value[i] = bsopt.AsianFwdVega(float(Fwd[i]), float(K[i]), float(Avg[i]), float(Vol[i]), Texp, float(Period[i]), float(Rf[i]))
    output['vega'] = value
    return JsonResponse(output)

def spread_option(request):
    return render(request, 'opt_calc/spread_option.html', {})

def kirk_approx(request):
    IsCall = request.GET.getlist('IsCall[]')
    Fwd1 = request.GET.getlist('Fwd1[]')
    Fwd2 = request.GET.getlist('Fwd2[]')
    Sigma1 = request.GET.getlist('Sigma1[]')
    Sigma2 = request.GET.getlist('Sigma2[]')
    K = request.GET.getlist('K[]')
    Corr = request.GET.getlist('Corr[]')
    t = request.GET.getlist('t[]')
    T = request.GET.getlist('T[]')
    Rf = request.GET.getlist('Rf[]')

    value = {}
    for i in range(len(IsCall)):
        d1 = datetime.strptime(str(t[i]), "%Y-%m-%d")
        d2 = datetime.strptime(str(T[i]), "%Y-%m-%d")
        delta = float((d2 - d1).days)
        Texp = float(delta / 365)
        value[i] = bsopt.KirkApprox(str(IsCall[i]), float(Fwd1[i]), float(Fwd2[i]), float(Sigma1[i]), float(Sigma2[i]),
                              float(Corr[i]), float(K[i]), Texp, float(Rf[i]))
    output = {'premium': value}
    return JsonResponse(output)