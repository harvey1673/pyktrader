function myFunction(){
        document.getElementById("change").innerHTML = "all changed by JS.";
        }