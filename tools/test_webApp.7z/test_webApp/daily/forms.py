from django import forms

class NameForm(forms.Form):
    your_name = forms.CharField(label='Your Name', max_length=128)
    
class SpotForm(forms.Form):
    spotID = forms.CharField(label='Input spotID', max_length=128)
    date_start = forms.DateField(label = 'Select start date', widget=forms.SelectDateWidget)
    date_end = forms.DateField(label = 'Select end date', widget = forms.SelectDateWidget)
    
class FutForm(forms.Form):
    instID = forms.CharField(label='Future tick symbol', max_length=10)
    date = forms.DateField(label = 'Select date', widget=forms.SelectDateWidget)
    
class UploadForm(forms.Form):
    ID = forms.IntegerField()
    misc = forms.CharField()
    
class BSForm(forms.Form):
    IsCall = forms.CharField(label='Input C for Call', max_length=1)
    S = forms.FloatField(label='Input stock price')
    K = forms.FloatField(label='Strike')
    Vol = forms.FloatField(label='Volatility')
    Texp = forms.FloatField(label='Time to maturity')
    Rf = forms.FloatField(label='Risk free rate')
    Rd = forms.FloatField(label='Divident yield')