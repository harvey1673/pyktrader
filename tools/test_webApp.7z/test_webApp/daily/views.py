# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse

# Create your views here.
import sqlite3
import pandas as pd
from .forms import NameForm, SpotForm, FutForm, UploadForm, BSForm
from .Data import Data
from .algorithms.bsopt import BSOpt, BSFwd, BSFwdDelta, BSFwdVega, KirkApprox, AsianOptTW_Fwd, AsianFwdDelta, AsianFwdGamma, AsianFwdTheta, AsianFwdVega
import json
from datetime import datetime, date
from risk_engine import *

def index(request):
    return render(request, 'daily/index.html', {})

def spot_price(request):
    valid = False
    if request.method == 'POST':
        form = SpotForm(request.POST)
        if form.is_valid():
            valid = True
            conn = sqlite3.connect('C:/Users/j291414/Desktop/market_data.db')
            spotID = form.cleaned_data['spotID']
            date_start = form.cleaned_data['date_start'].strftime('%Y-%m-%d')
            date_end = form.cleaned_data['date_end'].strftime('%Y-%m-%d')
            sql = "SELECT * FROM spot_daily WHERE spotID = '{}'".format(spotID)
            data = pd.read_sql_query(sql, conn)
            data = data.loc[(data['date']>=date_start)&(data['date']<=date_end)]
            date= list(data['date'])
            price = list(data['close'])
            conn.close()
          
            return render(request, 'daily/spot_price.html',{'data':data,
                                                            'form':form,
                                                            'valid':valid,
                                                            'date':date,
                                                            'price':price
                                                            })
#            return HttpResponse(date_start)
    else:
        form = SpotForm()
        return render(request, 'daily/spot_price.html', {'form':form,
                                                         'valid':valid,
                                                         })
    
def fut_curve(request):
    valid = False
    if request.method == 'POST':
        form = FutForm(request.POST)
        if form.is_valid():
            valid = True
            conn = sqlite3.connect('C:/Users/j291414/Desktop/market_data.db')
            instID = form.cleaned_data['instID']
            date = form.cleaned_data['date']
            sql = "SELECT instID, exch, date, close FROM fut_daily WHERE instID like '{}____' and date like '{}%'".format(instID, date)
            data = pd.read_sql_query(sql, conn)
            instID = list(data['instID'])
            price = list(data['close'])
            conn.close()
            return render(request, 'daily/fut_curve.html',{'data':data,
                                                            'form':form,
                                                            'valid':valid,
                                                            'instID':instID,
                                                            'price':price
                                                            })
    else:
        form = FutForm()
        return render(request, 'daily/fut_curve.html', {'form':form,
                                                         'valid':valid,
                                                         })
    
# option pricer
def BS_pricer(request):
    valid = False
    if request.method == 'POST':
       
        valid = True
        IsCall = request.POST.getlist('IsCall')
        S = request.POST.getlist('S')
        K = request.POST.getlist('K')
        Vol = request.POST.getlist('Vol')
        Texp = request.POST.getlist('Texp')
        Rf = request.POST.getlist('Rf')
        Rd = request.POST.getlist('Rd')
        res = []
        for i in range(len(IsCall)):
            res.append(BSOpt(IsCall[i], float(S[i]), float(K[i]), float(Vol[i]), float(Texp[i]), float(Rf[i]), float(Rd[i])))     
        return render(request, 'daily/BS_pricer.html', {'res':res, 'valid':valid})
    else:
        return render(request, 'daily/BS_pricer.html', {'valid':valid})
    
def bs_py(request):
    IsCall = request.GET.getlist('IsCall[]')
    F = request.GET.getlist('S[]')
    K = request.GET.getlist('K[]')
    Vol = request.GET.getlist('Vol[]')
    t = request.GET.getlist('t[]')
    T = request.GET.getlist('T[]')

    output = {}
    
    value = {}
    for i in range(len(IsCall)):
        d1 = datetime.strptime(str(t[i]), "%Y-%m-%d")
        d2 = datetime.strptime(str(T[i]), "%Y-%m-%d")
        delta = float((d2 - d1).days)
        Texp = float(delta/365)
        value[i] = BSFwd(str(IsCall[i]), float(F[i]), float(K[i]), float(Vol[i]), Texp)
    output['premium'] = value
    
    value = {}
    for i in range(len(IsCall)):
        d1 = datetime.strptime(str(t[i]), "%Y-%m-%d")
        d2 = datetime.strptime(str(T[i]), "%Y-%m-%d")
        delta = float((d2 - d1).days)
        Texp = float(delta/365)
        value[i] = BSFwdDelta(str(IsCall[i]), float(F[i]), float(K[i]), float(Vol[i]), Texp)
    output['delta'] = value
    
    value = {}
    for i in range(len(IsCall)):
        d1 = datetime.strptime(str(t[i]), "%Y-%m-%d")
        d2 = datetime.strptime(str(T[i]), "%Y-%m-%d")
        delta = float((d2 - d1).days)
        Texp = float(delta/365)
        value[i] = BSFwdVega(float(F[i]), float(K[i]), float(Vol[i]), Texp)
    output['vega'] = value
    
    
    return JsonResponse(output)
    
def spread_option(request):
    return render(request, 'daily/spread_option.html', {})

def kirk_approx(request):
    IsCall = request.GET.getlist('IsCall[]')
    Fwd1 = request.GET.getlist('Fwd1[]')
    Fwd2 = request.GET.getlist('Fwd2[]')
    Sigma1 = request.GET.getlist('Sigma1[]')
    Sigma2 = request.GET.getlist('Sigma2[]')
    K = request.GET.getlist('K[]')
    Corr = request.GET.getlist('Corr[]')
    t = request.GET.getlist('t[]')
    T = request.GET.getlist('T[]')
    Rf = request.GET.getlist('Rf[]')
    
    value = {}
    for i in range(len(IsCall)):
        d1 = datetime.strptime(str(t[i]), "%Y-%m-%d")
        d2 = datetime.strptime(str(T[i]), "%Y-%m-%d")
        delta = float((d2 - d1).days)
        Texp = float(delta/365)
        value[i] = KirkApprox(str(IsCall[i]), float(Fwd1[i]), float(Fwd2[i]), float(Sigma1[i]), float(Sigma2[i]), float(Corr[i]), float(K[i]), Texp, float(Rf[i]))
    output = {'premium': value}
    
    return JsonResponse(output)
    
# This part for querying trading books
def trade_book(request):
    if request.method == 'POST':
        tradeID = request.POST.getlist('tradeID')
        strat = request.POST.getlist('strategy')
        date = request.POST.getlist('enterDate')
        conn = sqlite3.connect('C:/Users/j291414/Desktop/option_data.db')
        sql = "select strategy, internal_id, enter_date, cpty, day1_comments, status \
                from deals \
                where strategy = '{}'".format(strat[0])
        data = pd.read_sql_query(sql, conn)
        conn.close()
        return render(request, 'daily/trading_book.html', {'data':data})
    else:
        return render(request, 'daily/trading_book.html', {})
    
# Asian Forward Option page
def AsianFwd_page(request):
    return render(request, 'daily/AsianFwd_page.html', {})

def AsianFwd(request):
    IsCall = request.GET.getlist('IsCall[]')
    Fwd = request.GET.getlist('Fwd[]')
    Avg = request.GET.getlist('Avg[]')
    Vol = request.GET.getlist('Vol[]')
    K = request.GET.getlist('K[]')
    Period = request.GET.getlist('Period[]')
    t = request.GET.getlist('t[]')
    T = request.GET.getlist('T[]')
    Rf = request.GET.getlist('Rf[]')
    
    output = {}
    
    value = {}
    for i in range(len(IsCall)):
        d1 = datetime.strptime(str(t[i]), "%Y-%m-%d")
        d2 = datetime.strptime(str(T[i]), "%Y-%m-%d")
        delta = float((d2 - d1).days)
        Texp = float(delta/365)
        value[i] = AsianOptTW_Fwd(str(IsCall[i]), float(Fwd[i]), float(K[i]), float(Avg[i]), float(Vol[i]), Texp, float(Period[i]), float(Rf[i]))
    output['premium'] = value
    
    value = {}
    for i in range(len(IsCall)):
        d1 = datetime.strptime(str(t[i]), "%Y-%m-%d")
        d2 = datetime.strptime(str(T[i]), "%Y-%m-%d")
        delta = float((d2 - d1).days)
        Texp = float(delta/365)
        value[i] = AsianFwdDelta(str(IsCall[i]), float(Fwd[i]), float(K[i]), float(Avg[i]), float(Vol[i]), Texp, float(Period[i]), float(Rf[i]))
    output['delta'] = value
    
    value = {}
    for i in range(len(IsCall)):
        d1 = datetime.strptime(str(t[i]), "%Y-%m-%d")
        d2 = datetime.strptime(str(T[i]), "%Y-%m-%d")
        delta = float((d2 - d1).days)
        Texp = float(delta/365)
        value[i] = AsianFwdGamma(float(Fwd[i]), float(K[i]), float(Avg[i]), float(Vol[i]), Texp, float(Period[i]), float(Rf[i]))
    output['gamma'] = value
    
    value = {}
    for i in range(len(IsCall)):
        d1 = datetime.strptime(str(t[i]), "%Y-%m-%d")
        d2 = datetime.strptime(str(T[i]), "%Y-%m-%d")
        delta = float((d2 - d1).days)
        Texp = float(delta/365)
        value[i] = AsianFwdTheta(str(IsCall[i]), float(Fwd[i]), float(K[i]), float(Avg[i]), float(Vol[i]), Texp, float(Period[i]), float(Rf[i]))
    output['theta'] = value
    
    value = {}
    for i in range(len(IsCall)):
        d1 = datetime.strptime(str(t[i]), "%Y-%m-%d")
        d2 = datetime.strptime(str(T[i]), "%Y-%m-%d")
        delta = float((d2 - d1).days)
        Texp = float(delta/365)
        value[i] = AsianFwdVega(float(Fwd[i]), float(K[i]), float(Avg[i]), float(Vol[i]), Texp, float(Period[i]), float(Rf[i]))
    output['vega'] = value
    
    return JsonResponse(output)

# For risk engine viewer
def risk_viewer(request):
    return render(request, 'daily/risk_viewer.html', {})

# Risk viewer backend logical calculations
def risk_processor(request):
    output = {}
    
    bookName = request.GET.getlist("bookName[]")
    date = request.GET.getlist("date[]")
    dt = datetime.strptime(str(date[0]), "%Y-%m-%d")
    dt = dt.date()
    bookName = str(bookName[0]).upper()
    
    vol, delta, gamma, vega, theta = risk_scen_report.run_book_report(dt, bookName)
    output['vol'] = vol.to_html()
    output['delta'] = delta.to_html()
    output['gamma'] = gamma.to_html()
    output['vega'] = vega.to_html()
    output['theta'] = theta.to_html()
    return JsonResponse(output)
                                                         


#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#                           Test Functions
##++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
def test_upload(request):
    if request.method == 'POST':
        form = UploadForm(request.POST)
        if form.is_valid():
            ID = form.cleaned_data['ID']
            misc = form.cleaned_data['misc']
            conn = sqlite3.connect('P:/test_webApp/db.sqlite3')
            c = conn.cursor()
            c.execute("INSERT INTO test_table VALUES (?, ?)", (ID, misc))
            conn.commit()
            conn.close()
            form2 = UploadForm()
            return render(request, 'daily/test_upload.html', {'form':form2})
    else:
        form = UploadForm()
    
        return render(request, 'daily/test_upload.html', {'form':form})






def df_to_dict(df):
    out = {}
    out['fields'] = list(df.columns)
    for field in df:
        out[field] = list(df[field])
    return out

# file charts.py
def simple(request):
    import random
    import django
    import datetime

    from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
    from matplotlib.figure import Figure
    from matplotlib.dates import DateFormatter

    fig=Figure()
    ax=fig.add_subplot(111)
    x=[]
    y=[]
    now=datetime.datetime.now()
    delta=datetime.timedelta(days=1)
    for i in range(10):
        x.append(now)
        now+=delta
        y.append(random.randint(0, 1000))
    ax.plot_date(x, y, '-')
    ax.xaxis.set_major_formatter(DateFormatter('%Y-%m-%d'))
    fig.autofmt_xdate()
    canvas=FigureCanvas(fig)
    response=django.http.HttpResponse(content_type='image/png')
    canvas.print_png(response)
    return response

# for solely testing purpose
def get_name(request):
    if request.method == 'POST':
        myInputs = request.POST.getlist('myInputs')
        return render(request, 'daily/get_name.html', {'myInputs':myInputs})
    else:
        return render(request, 'daily/get_name.html', {})
    
def test_ajax(request):
    return render(request, 'daily/test_ajax.html', {})

def test_ajax_python(request):
    inpt = request.GET.get('inpt', None)
    try:
        inpt = int(inpt)
    except ValueError:
        return JsonResponse({'value':'Wrong'})
    if inpt == 1:
        output = { 'value': '1' }
    else:
        output = { 'value' : '2' }
    return JsonResponse(output)

def test_ajax_list(request):
    inpt = request.GET.getlist('inpt[]')
    output = { 'value':inpt[0] }
    return JsonResponse(output)

def test_plotly(request):
    conn = sqlite3.connect("C:/Users/j291414/Desktop/market_data.db")
    sql = "select date, close as price from spot_daily where spotID = 'plt_io62'"
    data = Data(sql, conn)
    data = data.df
    date= data['date']
    out = []
    for e in date:
        out.append(e.strftime('%Y-%m-%d'))
    price = list(data['price'])
    conn.close()
    return render(request, 'daily/test_plotly.html', {'date':out,
                                                      'price':price})