-- MySQL dump 10.13  Distrib 5.6.19, for Win64 (x86_64)
--
-- Host: localhost    Database: blueshale
-- ------------------------------------------------------
-- Server version	5.6.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fut_daily`
--

DROP TABLE IF EXISTS `fut_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fut_daily` (
  `instID` varchar(30) NOT NULL,
  `exch` varchar(10) NOT NULL,
  `date` date NOT NULL,
  `open` decimal(12,4) DEFAULT NULL,
  `close` decimal(12,4) DEFAULT NULL,
  `high` decimal(12,4) DEFAULT NULL,
  `low` decimal(12,4) DEFAULT NULL,
  `volume` int(11) DEFAULT NULL,
  `openInterest` int(11) DEFAULT NULL,
  PRIMARY KEY (`instID`,`exch`,`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fut_min`
--

DROP TABLE IF EXISTS `fut_min`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fut_min` (
  `instID` varchar(30) NOT NULL,
  `exch` varchar(10) NOT NULL,
  `datetime` datetime NOT NULL,
  `date` date DEFAULT NULL,
  `min_id` int(11) DEFAULT NULL,
  `open` decimal(12,4) DEFAULT NULL,
  `close` decimal(12,4) DEFAULT NULL,
  `high` decimal(12,4) DEFAULT NULL,
  `low` decimal(12,4) DEFAULT NULL,
  `volume` int(11) DEFAULT NULL,
  `openInterest` int(11) DEFAULT NULL,
  PRIMARY KEY (`instID`,`exch`,`datetime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fut_tick`
--

DROP TABLE IF EXISTS `fut_tick`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fut_tick` (
  `instID` varchar(30) NOT NULL,
  `date` date NOT NULL,
  `tick_id` int(11) DEFAULT NULL,
  `hour` tinyint(4) NOT NULL,
  `min` tinyint(4) NOT NULL,
  `sec` tinyint(4) NOT NULL,
  `msec` smallint(6) NOT NULL,
  `openInterest` int(11) DEFAULT NULL,
  `volume` int(11) DEFAULT NULL,
  `price` decimal(12,4) DEFAULT NULL,
  `high` decimal(12,4) DEFAULT NULL,
  `low` decimal(12,4) DEFAULT NULL,
  `bidPrice1` decimal(12,4) DEFAULT NULL,
  `bidVol1` int(11) DEFAULT NULL,
  `askPrice1` decimal(12,4) DEFAULT NULL,
  `askVol1` int(11) DEFAULT NULL,
  PRIMARY KEY (`instID`,`date`,`hour`,`min`,`sec`,`msec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contract_list`
--

DROP TABLE IF EXISTS `contract_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_list` (
  `instID` varchar(15) NOT NULL,
  `start_date` date DEFAULT NULL,
  `expiry` date DEFAULT NULL,
  `product_code` varchar(10) DEFAULT NULL,
  `margin_l` decimal(10,4) DEFAULT NULL,
  `margin_s` decimal(10,4) DEFAULT NULL,
  PRIMARY KEY (`instID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trade_products`
--

DROP TABLE IF EXISTS `trade_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trade_products` (
  `product_code` varchar(10) DEFAULT NULL,
  `trading_start` date DEFAULT NULL,
  `exchange` varchar(10) DEFAULT NULL,
  `contract` varchar(20) DEFAULT NULL,
  `pricing_unit` varchar(10) DEFAULT NULL,
  `lot_size` int(11) DEFAULT NULL,
  `tick_size` decimal(10,4) DEFAULT NULL,
  `liquidity` decimal(3,1) DEFAULT NULL,
  `start_min` int(11) DEFAULT NULL,
  `end_min` int(11) DEFAULT NULL,
  `broker_fee` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-05  0:13:07
