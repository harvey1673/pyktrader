from django.conf.urls import url
from . import views



urlpatterns = [
        url(r'^$', views.index, name='index'),
        url(r'^spot/$', views.spot_price, name='spot'),
        url(r'^simple/$', views.simple, name='simple'),
        url(r'^name/$', views.get_name, name='name'),
        url(r'^fut/$', views.fut_curve, name='fut'),
        url(r'^test-upload/$', views.test_upload, name='test_upload'),
        url(r'^BS-pricer/$', views.BS_pricer, name='BS_pricer'),
        url(r'^spread-option/$', views.spread_option, name='spread_option'),
        url(r'^test_ajax/$', views.test_ajax, name='test_ajax'),
        url(r'^test_ajax_py/$', views.test_ajax_python, name='test_ajax_py'),
        url(r'^bs_py/$', views.bs_py, name='bs_py'),
        url(r'^trading-book/$', views.trade_book, name='trading_book'),
        url(r'^test_ajax_list/$', views.test_ajax_list, name='test_ajax_list'),
        url(r'^test_plotly/$', views.test_plotly, name='test_plotly'),
        url(r'^cal-spread/$', views.kirk_approx, name='kirk_approximate'),
        url(r'^asian-forward-option/$', views.AsianFwd_page, name='asian_fwd_page'),
        url(r'^asian-forward/$', views.AsianFwd, name='AsianFwd'),
        url(r'^risk-viewer/$', views.risk_viewer, name='risk_viewer'),
        url(r'^risk-processor/$', views.risk_processor, name='risk_processor'),
        url(r'^sync/$', views.sync, name='sync'),
        url(r'^2D-scenario/$', views.twod_scenario, name="2d_scenario"),
        url(r'^2D-scenario-cal/$', views.twod_scenario_cal, name='2d_scenario_cal'),
        url(r'^book-trade/$', views.book_trade, name='book_trade'),
        url(r'^test-fut-curve/$', views.test_fut_curve, name='test_fut_curve'),
	url(r'^test-mark-curve/$', views.test_mark_curve, name='test_mark_curve'),
    url(r'^test-compute-table/$', views.test_compute_table, name='test_compute_table'),
    url(r'^mark_curve/$', views.mark_curve, name='mark_curve'),
    url(r'^upload-fut-realtime-database/$', views.upload_fut_realtime_database, name='upload_fut_realtime_database'),
    
        ]